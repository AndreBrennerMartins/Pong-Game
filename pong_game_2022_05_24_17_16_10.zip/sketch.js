function setup() {
  createCanvas(600, 400);
}

let xBall=300
let yBall=200
let xSpeed=4
let ySpeed=4

let yPlayer=175
let xPlayer=10

let yEnemy=175
let xEnemy=580
let velEnemy=10

let pPoints=0
let ePoints=0
let pDial=" "
let eDial=" "
let blam=6

let hitsfx
let scoresfx

function draw() {
  background(0);
  ball();
  player(xPlayer,yPlayer);
  player(xEnemy,yEnemy);
  score();
  cheatkeys();
}

function preload(){
  hitsfx=loadSound("raquetada.mp3")
  scoresfx=loadSound("ponto.pm3")
}

function ball(){
  circle(xBall,yBall,20)
  xBall+=xSpeed
  yBall+=ySpeed
  
  //canvas colision
  if(xBall+10>width){
    xSpeed*=-1
    pPoints+=1
    scoresfx.play();
  }
  if(xBall-10<0){
    xSpeed*=-1
    ePoints+=1
    scoresfx.play();
  }
  if(yBall+10>height||yBall-10<0){
    ySpeed*=-1;
  }
  
  //player colision
  if(xBall-10<xPlayer+10&&yBall-10<yPlayer+60&&yBall+10>yPlayer){
    xSpeed*=-1
    hitsfx.play()
    velEnemy=random(0,15);
  }
  
  if(xBall+10>xEnemy-10&&yBall-10<yEnemy+60&&yBall+10>yEnemy){
    xSpeed*=-1
    hitsfx.play();
  }
}

function player(x, y){
  rect(x,y,10,60,2)
  playermove()
  enemymove()
}

function playermove(){
  if(keyIsDown(UP_ARROW)){
  yPlayer-=4
  }
  if(keyIsDown(DOWN_ARROW)){
  yPlayer+=4
  }
}

function enemymove(){
  if(yBall+velEnemy<yEnemy){
    yEnemy-=4
  }
  if(yBall-velEnemy>yEnemy+60){
    yEnemy+=4
  }
}

function score(){
  textSize(16)
  fill(255)
  text("player: "+pPoints,20,20)
  text("bot: "+ePoints,20,390)
  //dialogue
  text(pDial,200,20)
  text(eDial,200,390)
  
  if(pPoints>3000){
    pDial="..."
    eDial="..."
  }else if(pPoints>1500){
    pDial="Should we look for the ball?"
    eDial="I'll do that, you go find out what happened"
  }else if(pPoints>100){
    pDial="... what just happened?"
    eDial="Did the score break?"
  }else if(pPoints>20&&ePoints>20){
    pDial="That's a lot of score!"
    eDial="We've got you playing, huh?"
  }else if(ePoints>20&&pPoints<1){
    pDial="Oh"
    eDial="Dear god, you suck"
  }else if(pPoints>5){
    pDial="I got "+pPoints+" points!"
    eDial="Nice"
  }
  
  //if(pPoints<100&&ePoints<100){
    //if(pPoints<100){
      //text("player:"+pPoints,20,20)
    //}else{
      //text("player: did the game just break?",20,20)
    //}
    //if(ePoints<100){
      //text("bot:"+ePoints,20,390)
    //}else{
      //text("bot: ez!",20,390)
    //}
  //}else{
    //text("player: wait, why's this happening???",20,20)
    //text("bot: you know what you did",20,390)
  //}
}

function cheatkeys(){
  if(keyIsDown(90)){
    pPoints+=1
  }
  if(keyIsDown(88)){
    ePoints+=1
  }
  if(keyIsDown(67)){
    pPoints-=1
  }
  if(keyIsDown(86)){
    ePoints-=1
  }
}

